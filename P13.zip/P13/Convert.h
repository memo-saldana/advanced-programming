#define EXPORT __declspec(dllexport)

EXPORT int asciiBinaryToInt (char *s);
EXPORT int asciiHEXToInt (char *s);
EXPORT double asciiToDouble (char *s);
